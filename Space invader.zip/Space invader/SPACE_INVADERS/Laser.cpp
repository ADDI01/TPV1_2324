#include "Laser.h"
#include "Game.h"

void Laser::render() const
{
	if (!_hit) 
	{
		_myRect->x = _pos.getX();
		_myRect->y = _pos.getY();
		_myRect->w = 5;
		_myRect->h = 10;
		SDL_SetRenderDrawColor(_myrenderer, 0, 0, 255, 0xFF);
		SDL_RenderFillRect(_myrenderer, _myRect);
	}
}

bool Laser::update() 
{
	if (!_hit) 
	{//llamamos a la comprobaci�n de colisi�n
		if (_fatherPlayer)
		{
			//movimiento de la bala del jugador
			_pos = _pos - _velocity;
		}
		else
		{
			//movimiento de la bala de los alien�genas
			_pos = _pos + _velocity;
		}
	}
	return !_hit;
}