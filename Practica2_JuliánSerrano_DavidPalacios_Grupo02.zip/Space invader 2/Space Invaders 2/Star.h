#pragma once
#include "Vector2D.h"
#include "Texture.h"

using namespace std;
using uint = unsigned int;

class Star
{
private:
	//posici�n del background
	Point2D<float> _pos;
	//puntero a su Textura
	Texture* _texture;
	//Tama�o del alien
	pair<uint, uint> _size;

public:
	Star(Point2D<float> pos, Texture* texture, pair<uint, uint> size) : _pos(pos), _texture(texture), _size(size) {};

	void render() const {
		SDL_Rect destRect;
		destRect.x = 0;
		destRect.y = 0;
		destRect.w = _size.first;
		destRect.h = _size.second;

		_texture->render(destRect);
	};
};